/**
 * This file is released under the GNU General Public License.
 * Refer to the COPYING file distributed with this package.
 *
 * Copyright (c) 2008-2009 WURFL-Pro srl
 */
package net.sourceforge.wurfl.wng;

import net.sourceforge.wurfl.wng.component.InvalidContainmentException;

/**
 * Created by IntelliJ IDEA.
 * User: fanta
 * Date: 24-Feb-2009
 * Time: 13:46:40
 * To change this template use File | Settings | File Templates.
 */
public class WNGComponentTest {

    public void testAll() throws InvalidContainmentException {

        
    }
}
